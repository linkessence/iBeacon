//
//  main.m
//  blekeyfobdemo
//
//  Created by Joakim Lindh on 9/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TIBLEAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TIBLEAppDelegate class]));
    }
}
