//
//  AppDelegate.h
//  ThermometerDemo
//
//  Created by liuyu on 13-7-9.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
