//
//  ViewController.h
//  ThermometerDemo
//
//  Created by liuyu on 13-7-9.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface ViewController : UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate>{
}

@property bool cbReady;
@property (nonatomic,strong) CBCentralManager *cbCM;
@property (strong,nonatomic) NSMutableArray *nDevices;
@property (strong,nonatomic) NSMutableArray *nServices;
@property (strong,nonatomic) NSMutableArray *nCharacteristics;

@property (strong,nonatomic) CBPeripheral *cbPeripheral;
@property (strong,nonatomic) CBService *cbServices;
@property (strong,nonatomic) CBCharacteristic *cbCharacteristcs;

@property (weak, nonatomic) IBOutlet UITextView *dbgText;
- (IBAction)scanButton:(id)sender;

- (IBAction)connectPeripheral:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *peripheralFound;

- (IBAction)readButton:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *labelTemp;
@property (weak, nonatomic) IBOutlet UIButton *readButtonStatus;
@end
