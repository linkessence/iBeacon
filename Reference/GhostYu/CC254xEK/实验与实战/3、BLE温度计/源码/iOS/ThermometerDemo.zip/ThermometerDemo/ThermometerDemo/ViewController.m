//
//  ViewController.m
//  ThermometerDemo
//
//  Created by liuyu on 13-7-9.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


@synthesize cbReady;
@synthesize cbCM;
@synthesize cbPeripheral;
@synthesize cbServices;
@synthesize cbCharacteristcs;


@synthesize nDevices;
@synthesize nServices;
@synthesize nCharacteristics;

@synthesize dbgText;
@synthesize labelTemp;
@synthesize peripheralFound;
@synthesize readButtonStatus;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self updateLog:@"Initializing BLE\r\n"];
    cbCM = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    cbServices =[[CBService alloc]init];
    cbCharacteristcs =[[CBCharacteristic alloc]init];
    
    //列表初始化
    nDevices = [[NSMutableArray alloc]init];
    nServices = [[NSMutableArray alloc]init];
    nCharacteristics = [[NSMutableArray alloc]init];
    
    cbReady = false;
    peripheralFound.hidden = true;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)updateLog:(NSString *)s
{
    static unsigned int count = 0;
    
    [dbgText setText:[NSString stringWithFormat:@"[ %d ]  %@\r\n%@",count,s,dbgText.text]];
    count++;
}

-(void)writeCharacteristic:(CBPeripheral *)peripheral sUUID:(NSString *)sUUID cUUID:(NSString *)cUUID data:(NSData *)data {
    // Sends data to BLE peripheral to process HID and send EHIF command to PC
    for ( CBService *service in peripheral.services ) {
        
        if ([service.UUID isEqual:[CBUUID UUIDWithString:sUUID]]) {
            
            for ( CBCharacteristic *characteristic in service.characteristics ) {
                if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:cUUID]]) {
                    [self updateLog:@"has reached\r\n"];
                    /* EVERYTHING IS FOUND, WRITE characteristic ! */
                    
                    [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];
                    
                }
            }
        }
    }
}
-(void)setNotificationForCharacteristic:(CBPeripheral *)peripheral sUUID:(NSString *)sUUID cUUID:(NSString *)cUUID enable:(BOOL)enable {
    for ( CBService *service in peripheral.services ) {
        if ([service.UUID isEqual:[CBUUID UUIDWithString:sUUID]]) {
            for (CBCharacteristic *characteristic in service.characteristics ) {
                if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:cUUID]])
                {
                    /* Everything is found, set notification ! */
                    [peripheral setNotifyValue:enable forCharacteristic:characteristic];
                    
                }
                
            }
        }
    }
}
//delegate of CBCentralManager
-(void)centralManagerDidUpdateState:(CBCentralManager *)central {
    cbReady = false;
    switch (central.state) {
        case CBCentralManagerStatePoweredOff:
            [self updateLog:@"CoreBluetooth BLE hardware is Powered off"];
            
            break;
        case CBCentralManagerStatePoweredOn:
            [self updateLog:@"CoreBluetooth BLE hardware is Powered on and ready"];
            //cbReady = true;
        case CBCentralManagerStateResetting:
            
            [self updateLog:@"CoreBluetooth BLE hardware is resetting"];
            break;
        case CBCentralManagerStateUnauthorized:
            
            [self updateLog:@"CoreBluetooth BLE state is unauthorized"];
            break;
        case CBCentralManagerStateUnknown:
            
            [self updateLog:@"CoreBluetooth BLE state is unknown"];
            break;
        case CBCentralManagerStateUnsupported:
            
            [self updateLog:@"CoreBluetooth BLE hardware is unsupported on this platform"];
            break;
        default:
            break;
    }
    
}

//已发现从机设备
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    [self updateLog:[NSString stringWithFormat:@"Did discover peripheral. peripheral: %@ rssi: %@, UUID: %@ advertisementData: %@ ", peripheral, RSSI, peripheral.UUID, advertisementData]];
    
    BOOL replace = NO;
    
    // Match if we have this device from before
    
    for (int ii=0; ii < nDevices.count; ii++) {
        CBPeripheral *p = [nDevices objectAtIndex:ii];
        if ([p isEqual:peripheral]) {
            [nDevices replaceObjectAtIndex:ii withObject:peripheral];
            replace = YES;
        }
    }
    if (!replace) {
        if ([peripheral.name isEqualToString:@"GhostyuTempDemo"]) {
            [nDevices addObject:peripheral];
            [self updateLog:@"has found GhostyuTempDemo！\r\n"];
            
            cbPeripheral = peripheral;
            [peripheralFound setTitle:[NSString stringWithFormat:@"%@",peripheral.name] forState:UIControlStateNormal];
            peripheralFound.hidden = false;
            
        }
        
    }
    
    
}


//已链接到从机
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    
    [self updateLog:[NSString stringWithFormat:@"Connection successfull to peripheral: %@ with UUID: %@",peripheral,peripheral.UUID]];
    //Do somenthing after successfull connection.
    
    [peripheralFound setTitle:[NSString stringWithFormat:@"%@: Has Connected",peripheral.name] forState:UIControlStateNormal];
    
    //发现services
    //设置peripheral的delegate未self非常重要，否则，didDiscoverServices无法回调
    peripheral.delegate = self;
    [cbPeripheral discoverServices:nil];
    [self updateLog:@"finding services"];
}


//已断开从机的链接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    [self updateLog:[NSString stringWithFormat:@"Disconnected from peripheral: %@ with UUID: %@",peripheral,peripheral.UUID]];
    //Do something when a peripheral is disconnected.
    
    [peripheralFound setTitle:[NSString stringWithFormat:@"%@: Has Disconnected",peripheral.name] forState:UIControlStateNormal];
    
}

- (void) centralManager:(CBCentralManager *)central didRetrieveConnectedPeripherals:(NSArray *)peripherals {
    
    [self updateLog:[NSString stringWithFormat:@"Currently connected peripherals :"]];
    int i = 0;
    for(CBPeripheral *peripheral in peripherals) {
        [self updateLog:[NSString stringWithFormat:@"[%d] - peripheral : %@ with UUID : %@",i,peripheral,peripheral.UUID]];
        //Do something on each connected peripheral.
    }
    
}

- (void) centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals {
    
    [self updateLog:[NSString stringWithFormat:@"Currently known peripherals :"]];
    int i = 0;
    for(CBPeripheral *peripheral in peripherals) {
        
        [self updateLog:[NSString stringWithFormat:@"[%d] - peripheral : %@ with UUID : %@",i,peripheral,peripheral.UUID]];
        //Do something on each known peripheral.
    }
}





//delegate of CBPeripheral
//已搜索到services
-(void) peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    
    [self updateLog:@"Found Services."];
    
    int i=0;
    for (CBService *s in peripheral.services) {
        
        [self.nServices addObject:s];
        
    }
    
    
    for (CBService *s in peripheral.services) {
        [self updateLog:[NSString stringWithFormat:@"%d :Service UUID: %@(%@)",i,s.UUID.data,s.UUID]];
        i++;
        [peripheral discoverCharacteristics:nil forService:s];
    }
}

//已搜索到Characteristics
-(void) peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    [self updateLog:[NSString stringWithFormat:@"Found Characteristics in Service:%@ (%@)",service.UUID.data ,service.UUID]];
    
    for (CBCharacteristic *c in service.characteristics) {
        [self updateLog:[NSString stringWithFormat:@"Characteristic UUID: %@ (%@)",c.UUID.data,c.UUID]];
        [nCharacteristics addObject:c];
        
    }
}
//已读到char
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        return;
    }
    
    unsigned char data[characteristic.value.length];
    [characteristic.value getBytes:&data];
    
    [labelTemp setText:[NSString stringWithFormat:@"%d",data[0]]];
    
    NSDate*date = [NSDate date];
    NSCalendar*calendar = [NSCalendar currentCalendar];
    NSDateComponents*comps;
    comps =[calendar components:(NSHourCalendarUnit | NSMinuteCalendarUnit |NSSecondCalendarUnit) fromDate:date];
    
    NSInteger hour = [comps hour];
    NSInteger minute = [comps minute];
    NSInteger second = [comps second];
    
    [self updateLog:[NSString stringWithFormat:@"char update! [%d:%d:%d]",hour,minute,second]];
}

- (IBAction)scanButton:(id)sender {
    [self updateLog:@"Scan for Peripheral..."];
    [cbCM scanForPeripheralsWithServices:nil options:nil];
}

- (IBAction)connectPeripheral:(id)sender {
    if (cbReady ==false) {
        [self.cbCM connectPeripheral:cbPeripheral options:nil];
        cbReady = true;
    }else {
        [self.cbCM cancelPeripheralConnection:cbPeripheral];
        cbReady = false;
    }}
- (IBAction)readButton:(id)sender {
    static int notifyFlag=0;
    if (notifyFlag==0) {
        [self setNotificationForCharacteristic:cbPeripheral sUUID:@"FFF0" cUUID:@"FFF4" enable:TRUE];
        [self updateLog:@"Start Notification"];
        notifyFlag = 1;
        [readButtonStatus setTitle:@"Stop" forState:UIControlStateNormal];
        
    }else if (notifyFlag ==1){
        [self setNotificationForCharacteristic:cbPeripheral sUUID:@"FFF0" cUUID:@"FFF4" enable:false];
        [self updateLog:@"Stop Notification"];
        notifyFlag = 0;
        [readButtonStatus setTitle:@"Start" forState:UIControlStateNormal];
        [labelTemp setText:@"0"];

    }

}
@end
