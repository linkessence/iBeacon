//
//  ViewController.h
//  七彩灯
//
//  Created by liuyu on 13-10-12.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>


@interface ViewController : UIViewController <CBCentralManagerDelegate,CBPeripheralDelegate>{
    UIImageView *colorImg;
    UIImageView *selColorImg;
    UIImageView *selImage;
    
    UIButton *btnHSBH;
    UIButton *btnHSBS;
    UIButton *btnHSBB;
    UIButton *btnRGBR;
    UIButton *btnRGBG;
    UIButton *btnRGBB;
    UITextField *txtHSBH;
    UITextField *txtHSBS;
    UITextField *txtHSBB;
    UITextField *txtRGBR;
    UITextField *txtRGBG;
    UITextField *txtRGBB;
    
    UIColor *lastColor;
}

@property bool cbReady;
@property (nonatomic,strong) CBCentralManager *cbCM;
@property (strong,nonatomic) CBPeripheral *cbPeripheral;
@property (strong,nonatomic) CBService *cbServices;
@property (strong,nonatomic) CBCharacteristic *cbCharacteristcs;

@property (strong,nonatomic) NSMutableArray *nDevices;
@property (strong,nonatomic) NSMutableArray *nServices;
@property (strong,nonatomic) NSMutableArray *nCharacteristics;

@property(nonatomic, retain)UIImageView *colorImg;
@property(nonatomic, retain)UIImageView *selColorImg;
@property(nonatomic, retain)UIColor *lastColor;
@property(nonatomic, retain)UIButton *btnHSBH;
@property(nonatomic, retain)UIButton *btnHSBS;
@property(nonatomic, retain)UIButton *btnHSBB;
@property(nonatomic, retain)UIButton *btnRGBR;
@property(nonatomic, retain)UIButton *btnRGBG;
@property(nonatomic, retain)UIButton *btnRGBB;
@property(nonatomic, retain)UITextField *txtHSBH;
@property(nonatomic, retain)UITextField *txtHSBS;
@property(nonatomic, retain)UITextField *txtHSBB;
@property(nonatomic, retain)UITextField *txtRGBR;
@property(nonatomic, retain)UITextField *txtRGBG;
@property(nonatomic, retain)UITextField *txtRGBB;
- (CGContextRef) createARGBBitmapContextFromImage:(CGImageRef) inImage;
- (UIColor*) getPixelColorAtLocation:(CGPoint)point;
- (void)initWithFrameGhostyu;

@property (weak, nonatomic) IBOutlet UITextView *dbgText;
@property (weak, nonatomic) IBOutlet UIButton *peripheralFound;
- (IBAction)scanButton:(id)sender;
- (IBAction)connectPeripheral:(id)sender;

@end
