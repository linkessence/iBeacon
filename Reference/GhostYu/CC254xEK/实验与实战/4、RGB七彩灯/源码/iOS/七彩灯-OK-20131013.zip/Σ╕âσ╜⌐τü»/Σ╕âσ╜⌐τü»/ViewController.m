//
//  ViewController.m
//  七彩灯
//
//  Created by liuyu on 13-10-12.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

#define pointY 100
@implementation ViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self initWithFrameGhostyu];
    
    [self updateLog:@"Initializing BLE\r\n"];
    cbCM = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    cbServices =[[CBService alloc]init];
    cbCharacteristcs =[[CBCharacteristic alloc]init];
    
    //列表初始化
    nDevices = [[NSMutableArray alloc]init];
    nServices = [[NSMutableArray alloc]init];
    nCharacteristics = [[NSMutableArray alloc]init];
    
    cbReady = false;
    peripheralFound.hidden = true;}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@synthesize colorImg;
@synthesize selColorImg;
@synthesize lastColor;

@synthesize dbgText;
@synthesize cbReady;
@synthesize cbCM;
@synthesize cbPeripheral;
@synthesize cbServices;
@synthesize cbCharacteristcs;


@synthesize nDevices;
@synthesize nServices;
@synthesize nCharacteristics;


@synthesize peripheralFound;


@synthesize btnHSBH;
@synthesize btnHSBS;
@synthesize btnHSBB;
@synthesize btnRGBR;
@synthesize btnRGBG;
@synthesize btnRGBB;
@synthesize txtHSBH;
@synthesize txtHSBS;
@synthesize txtHSBB;
@synthesize txtRGBR;
@synthesize txtRGBG;
@synthesize txtRGBB;


- (void)initWithFrameGhostyu
{
    
       // Initialization code
#if 0
        UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(110, pointY - 60, 100, 28)];
        lblTitle.font = [UIFont systemFontOfSize:18];
        lblTitle.text = @"颜色选择";
        lblTitle.backgroundColor = [UIColor clearColor];
        lblTitle.textColor = [UIColor whiteColor];
        //lblTitle.textAlignment = UITextAlignmentCenter;
        [self.view  addSubview:lblTitle];
#endif
        colorImg = [[UIImageView alloc]initWithFrame:CGRectMake(20, pointY, 210, 210)];
        colorImg.image = [UIImage imageNamed:@"allcolor2.png"];
        [self.view  addSubview:colorImg];
        
        selColorImg = [[UIImageView alloc]initWithFrame:CGRectMake(250, pointY + 20, 50, 50)];
        selColorImg.backgroundColor = [UIColor colorWithRed:0 green:1 blue:1 alpha:1];
        lastColor = selColorImg.backgroundColor;
        [self.view  addSubview:selColorImg];
        
        selImage =[[UIImageView alloc]initWithFrame:CGRectMake((210 + 20)/2, pointY + (210-20)/2, 20, 20)];
        selImage.image = [UIImage imageNamed:@"select.png"];
        [self.view  addSubview:selImage];
#if 0
        UIButton *btnOk=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        [btnOk setTitle:@"确定" forState:UIControlStateNormal];
        btnOk.frame = CGRectMake(50, 400, 100, 30);
        btnOk.backgroundColor = [UIColor clearColor];
        btnOk.tag =201;
        // 设置事件
        //[btnOk addTarget:self action:@selector(btnPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btnOk];
        
        UIButton *btnCancel=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        [btnCancel setTitle:@"取消" forState:UIControlStateNormal];
        btnCancel.frame = CGRectMake(170, 400, 100, 30);
        btnCancel.backgroundColor = [UIColor clearColor];
        btnCancel.tag =202;
        // 设置事件
        //[btnCancel addTarget:self action:@selector(btnPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self.view  addSubview:btnCancel];
#endif
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void) touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event {
	if (self.view.hidden==YES) {
		//color wheel is hidden, so don't handle  this as a color wheel event.
		[[self nextResponder] touchesEnded:touches withEvent:event];
		return;
	}
	
	UITouch* touch = [touches anyObject];
	CGPoint point = [touch locationInView:colorImg]; //where image was tapped
    if(point.x < 0 || point.x > 210 || point.y<0 || point.y >210){
        return;
    }
    if(point.y < 105){
        selImage.image = [UIImage imageNamed:@"select2.png"];
    }else
    {
        selImage.image = [UIImage imageNamed:@"select.png"];
    }
    selImage.center = CGPointMake(point.x + 20, point.y + pointY);
	lastColor = [self getPixelColorAtLocation:point];
    
	[self LightControl:lastColor];
    
    //NSLog(@"color: %@",lastColor);
    selColorImg.backgroundColor = lastColor;
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch* touch = [touches anyObject];
	CGPoint point = [touch locationInView:colorImg]; //where image was tapped
    if(point.x < 0 || point.x > 211 || point.y<0 || point.y >211){
        return;
    }
    if(point.y < 105){
        selImage.image = [UIImage imageNamed:@"select2.png"];
    }else
    {
        selImage.image = [UIImage imageNamed:@"select.png"];
    }
    selImage.center = CGPointMake(point.x + 20, point.y + pointY);
	lastColor = [self getPixelColorAtLocation:point];
    [self LightControl:lastColor];
    selColorImg.backgroundColor = lastColor;
    
}

- (UIColor*) getPixelColorAtLocation:(CGPoint)point {
	UIColor* color = nil;
	CGImageRef inImage = colorImg.image.CGImage;
	// Create off screen bitmap context to draw the image into. Format ARGB is 4 bytes for each pixel: Alpa, Red, Green, Blue
	CGContextRef cgctx = [self createARGBBitmapContextFromImage:inImage];
	if (cgctx == NULL) { return nil; /* error */ }
	
    size_t w = CGImageGetWidth(inImage);
	size_t h = CGImageGetHeight(inImage);
	CGRect rect = {{0,0},{w,h}};
	
	// Draw the image to the bitmap context. Once we draw, the memory
	// allocated for the context for rendering will then contain the
	// raw image data in the specified color space.
	CGContextDrawImage(cgctx, rect, inImage);
	
	// Now we can get a pointer to the image data associated with the bitmap
	// context.
	unsigned char* data = CGBitmapContextGetData (cgctx);
	if (data != NULL) {
		//offset locates the pixel in the data from x,y.
		//4 for 4 bytes of data per pixel, w is width of one row of data.
		int offset = 4*((w*round(point.y))+round(point.x));
		int alpha =  data[offset];
		int red = data[offset+1];
		int green = data[offset+2];
		int blue = data[offset+3];
		NSLog(@"offset: %i colors: RGB A %i %i %i  %i",offset,red,green,blue,alpha);
		color = [UIColor colorWithRed:(red/255.0f) green:(green/255.0f) blue:(blue/255.0f) alpha:(alpha/255.0f)];
	}
	
	// When finished, release the context
	CGContextRelease(cgctx);
	// Free image data memory for the context
	if (data) { free(data); }
	
	return color;
}



- (CGContextRef) createARGBBitmapContextFromImage:(CGImageRef) inImage {
	
	CGContextRef    context = NULL;
	CGColorSpaceRef colorSpace;
	void *          bitmapData;
	int             bitmapByteCount;
	int             bitmapBytesPerRow;
	
	// Get image width, height. We'll use the entire image.
	size_t pixelsWide = CGImageGetWidth(inImage);
	size_t pixelsHigh = CGImageGetHeight(inImage);
	
	// Declare the number of bytes per row. Each pixel in the bitmap in this
	// example is represented by 4 bytes; 8 bits each of red, green, blue, and
	// alpha.
	bitmapBytesPerRow   = (pixelsWide * 4);
	bitmapByteCount     = (bitmapBytesPerRow * pixelsHigh);
	
	// Use the generic RGB color space.
	colorSpace = CGColorSpaceCreateDeviceRGB();
    
	if (colorSpace == NULL)
	{
		fprintf(stderr, "Error allocating color space\n");
		return NULL;
	}
	
	// Allocate memory for image data. This is the destination in memory
	// where any drawing to the bitmap context will be rendered.
	bitmapData = malloc( bitmapByteCount );
	if (bitmapData == NULL)
	{
		fprintf (stderr, "Memory not allocated!");
		CGColorSpaceRelease( colorSpace );
		return NULL;
	}
	
	// Create the bitmap context. We want pre-multiplied ARGB, 8-bits
	// per component. Regardless of what the source image format is
	// (CMYK, Grayscale, and so on) it will be converted over to the format
	// specified here by CGBitmapContextCreate.
	context = CGBitmapContextCreate (bitmapData,
									 pixelsWide,
									 pixelsHigh,
									 8,      // bits per component
									 bitmapBytesPerRow,
									 colorSpace,
									 kCGImageAlphaPremultipliedFirst);
	if (context == NULL)
	{
		free (bitmapData);
		//fprintf (stderr, "Context not created!");
	}
	
	// Make sure and release colorspace before returning
	CGColorSpaceRelease( colorSpace );
	
	return context;
}

//通过rgb来控制led灯的rgb调色。
-(void)LightControl:(UIColor *)color
{
    CGFloat r,g,b,a;
    unsigned char R,G,B;
    //[self updateLog:[NSString stringWithFormat:@"color: %@",color]];
    [color getRed:&r green:&g blue:&b alpha:&a];
    R = 255*r;
    G = 255*g;
    B = 255*b;
    [self updateLog:[NSString stringWithFormat:@"Red:%hhu, Green:%hhu, Blue:%hhu",R,G,B]];
    
    if (cbReady ==TRUE) {
        unsigned char dat[3]={R,G,B};
        [self writeCharacteristic:cbPeripheral sUUID:@"FFF0" cUUID:@"FFF1" data:[NSData dataWithBytes:dat length:3]];
    }
}
    

-(void)updateLog:(NSString *)s
{
    static unsigned int count = 0;
    
    [dbgText setText:[NSString stringWithFormat:@"[ %d ]  %@\r\n%@",count,s,dbgText.text]];
    count++;
}

-(void)writeCharacteristic:(CBPeripheral *)peripheral sUUID:(NSString *)sUUID cUUID:(NSString *)cUUID data:(NSData *)data {
    // Sends data to BLE peripheral to process HID and send EHIF command to PC
    for ( CBService *service in peripheral.services ) {
        
        if ([service.UUID isEqual:[CBUUID UUIDWithString:sUUID]]) {
            
            for ( CBCharacteristic *characteristic in service.characteristics ) {
                if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:cUUID]]) {
                    //[self updateLog:@"has reached\r\n"];
                    /* EVERYTHING IS FOUND, WRITE characteristic ! */
                    
                    [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];
                    
                }
            }
        }
    }
}

//delegate of CBCentralManager
-(void)centralManagerDidUpdateState:(CBCentralManager *)central {
    cbReady = false;
    switch (central.state) {
        case CBCentralManagerStatePoweredOff:
            [self updateLog:@"CoreBluetooth BLE hardware is Powered off"];
            
            break;
        case CBCentralManagerStatePoweredOn:
            [self updateLog:@"CoreBluetooth BLE hardware is Powered on and ready"];
            //cbReady = true;
        case CBCentralManagerStateResetting:
            
            [self updateLog:@"CoreBluetooth BLE hardware is resetting"];
            break;
        case CBCentralManagerStateUnauthorized:
            
            [self updateLog:@"CoreBluetooth BLE state is unauthorized"];
            break;
        case CBCentralManagerStateUnknown:
            
            [self updateLog:@"CoreBluetooth BLE state is unknown"];
            break;
        case CBCentralManagerStateUnsupported:
            
            [self updateLog:@"CoreBluetooth BLE hardware is unsupported on this platform"];
            break;
        default:
            break;
    }
    
}

//已发现从机设备
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    [self updateLog:[NSString stringWithFormat:@"Did discover peripheral. peripheral: %@ rssi: %@, UUID: %@ advertisementData: %@ ", peripheral, RSSI, peripheral.UUID, advertisementData]];
    
    BOOL replace = NO;
    
    // Match if we have this device from before
    
    for (int ii=0; ii < nDevices.count; ii++) {
        CBPeripheral *p = [nDevices objectAtIndex:ii];
        if ([p isEqual:peripheral]) {
            [nDevices replaceObjectAtIndex:ii withObject:peripheral];
            replace = YES;
        }
    }
    if (!replace) {
#ifdef GHOSTYU_RGBLIGHT_NAMED
        if ([peripheral.name isEqualToString:@"GhostyuLEDDemo"]) {
#endif
            [nDevices addObject:peripheral];
            [self updateLog:@"has found！\r\n"];
            
            cbPeripheral = peripheral;
            [peripheralFound setTitle:[NSString stringWithFormat:@"%@",peripheral.name] forState:UIControlStateNormal];
            peripheralFound.hidden = false;
#ifdef GHOSTYU_RGBLIGHT_NAMED
        }
#endif
        
    }
    
    
}


//已链接到从机
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    
    [self updateLog:[NSString stringWithFormat:@"Connection successfull to peripheral: %@ with UUID: %@",peripheral,peripheral.UUID]];
    //Do somenthing after successfull connection.
    
    [peripheralFound setTitle:@"Connected" forState:UIControlStateNormal];
    
    //发现services
    //设置peripheral的delegate未self非常重要，否则，didDiscoverServices无法回调
    peripheral.delegate = self;
    [cbPeripheral discoverServices:nil];
    [self updateLog:@"finding services"];
}


//已断开从机的链接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    [self updateLog:[NSString stringWithFormat:@"Disconnected from peripheral: %@ with UUID: %@",peripheral,peripheral.UUID]];
    //Do something when a peripheral is disconnected.
    
    [peripheralFound setTitle:@"Disconnected" forState:UIControlStateNormal];
    
}

- (void) centralManager:(CBCentralManager *)central didRetrieveConnectedPeripherals:(NSArray *)peripherals {
    
    [self updateLog:[NSString stringWithFormat:@"Currently connected peripherals :"]];
    int i = 0;
    for(CBPeripheral *peripheral in peripherals) {
        [self updateLog:[NSString stringWithFormat:@"[%d] - peripheral : %@ with UUID : %@",i,peripheral,peripheral.UUID]];
        //Do something on each connected peripheral.
    }
    
}

- (void) centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals {
    
    [self updateLog:[NSString stringWithFormat:@"Currently known peripherals :"]];
    int i = 0;
    for(CBPeripheral *peripheral in peripherals) {
        
        [self updateLog:[NSString stringWithFormat:@"[%d] - peripheral : %@ with UUID : %@",i,peripheral,peripheral.UUID]];
        //Do something on each known peripheral.
    }
}





//delegate of CBPeripheral
//已搜索到services
-(void) peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    
    [self updateLog:@"Found Services."];
    
    int i=0;
    for (CBService *s in peripheral.services) {
        
        [self.nServices addObject:s];
        
    }
    
    
    for (CBService *s in peripheral.services) {
        [self updateLog:[NSString stringWithFormat:@"%d :Service UUID: %@(%@)",i,s.UUID.data,s.UUID]];
        i++;
        [peripheral discoverCharacteristics:nil forService:s];
    }
}

//已搜索到Characteristics
-(void) peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    [self updateLog:[NSString stringWithFormat:@"Found Characteristics in Service:%@ (%@)",service.UUID.data ,service.UUID]];
    
    for (CBCharacteristic *c in service.characteristics) {
        [self updateLog:[NSString stringWithFormat:@"Characteristic UUID: %@ (%@)",c.UUID.data,c.UUID]];
        [nCharacteristics addObject:c];
        
    }
}
//已读到char
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        return;
    }
    unsigned char data[characteristic.value.length];
    [characteristic.value getBytes:&data];
    
    
}

- (IBAction)scanButton:(id)sender {
    [self updateLog:@"Scan for Peripheral..."];
    [cbCM scanForPeripheralsWithServices:nil options:nil];}

- (IBAction)connectPeripheral:(id)sender {
    if (cbReady ==false) {
        [self.cbCM connectPeripheral:cbPeripheral options:nil];
        cbReady = true;
    }else {
        [self.cbCM cancelPeripheralConnection:cbPeripheral];
        cbReady = false;
    }
}
@end
