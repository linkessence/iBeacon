//
//  main.m
//  七彩灯
//
//  Created by liuyu on 13-10-12.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
