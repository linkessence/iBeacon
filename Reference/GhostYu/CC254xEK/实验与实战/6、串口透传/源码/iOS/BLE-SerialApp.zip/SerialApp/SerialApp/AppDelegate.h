//
//  AppDelegate.h
//  SerialApp
//
//  Created by liuyu on 13-6-4.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
