//
//  ViewController.h
//  SerialApp
//
//  Created by liuyu on 13-6-4.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface ViewController : UIViewController <CBCentralManagerDelegate,CBPeripheralDelegate>{
    
}

@property bool cbReady;
@property (nonatomic,strong) CBCentralManager *cbCM;
@property (strong,nonatomic) NSMutableArray *nDevices;
@property (strong,nonatomic) NSMutableArray *nServices;
@property (strong,nonatomic) NSMutableArray *nCharacteristics;

@property (strong,nonatomic) CBPeripheral *cbPeripheral;
@property (strong,nonatomic) CBService *cbServices;
@property (strong,nonatomic) CBCharacteristic *cbCharacteristcs;

@property (weak, nonatomic) IBOutlet UITextView *dbgText;
@property (weak, nonatomic) IBOutlet UIButton *peripheralFound;
@property (weak, nonatomic) IBOutlet UITextField *textSend;

- (IBAction)scanButton:(id)sender;
- (IBAction)connectPeripheral:(id)sender;
- (IBAction)sendMsg:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *buttonSend;

@end
