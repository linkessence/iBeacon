//
//  ViewController.m
//  SerialApp
//
//  Created by liuyu on 13-6-4.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


@synthesize dbgText;
@synthesize cbReady;
@synthesize cbCM;
@synthesize cbPeripheral;
@synthesize cbServices;
@synthesize cbCharacteristcs;


@synthesize nDevices;
@synthesize nServices;
@synthesize nCharacteristics;


@synthesize peripheralFound;
@synthesize textSend;
@synthesize buttonSend;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self updateLog:@"Initializing BLE\r\n"];
    cbCM = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    cbServices =[[CBService alloc]init];
    cbCharacteristcs =[[CBCharacteristic alloc]init];
    
    //列表初始化
    nDevices = [[NSMutableArray alloc]init];
    nServices = [[NSMutableArray alloc]init];
    nCharacteristics = [[NSMutableArray alloc]init];
    
    cbReady = false;
    peripheralFound.hidden = true;
    textSend.hidden = true;
    buttonSend.hidden = true;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)updateLog:(NSString *)s
{
    static unsigned int count = 0;
    
    [dbgText setText:[NSString stringWithFormat:@"[ %d ]  %@\r\n%@",count,s,dbgText.text]];
    count++;
}



-(void)writeCharacteristic:(CBPeripheral *)peripheral sUUID:(NSString *)sUUID cUUID:(NSString *)cUUID data:(NSData *)data {
    // Sends data to BLE peripheral to process HID and send EHIF command to PC
    for ( CBService *service in peripheral.services ) {
        
        if ([service.UUID isEqual:[CBUUID UUIDWithString:sUUID]]) {
            
            for ( CBCharacteristic *characteristic in service.characteristics ) {
                if ([characteristic.UUID isEqual:[CBUUID UUIDWithString:cUUID]]) {
                    /* EVERYTHING IS FOUND, WRITE characteristic ! */
                    [peripheral writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];
                    
                }
            }
        }
    }
}

//delegate of CBCentralManager
-(void)centralManagerDidUpdateState:(CBCentralManager *)central {
    cbReady = false;
    switch (central.state) {
        case CBCentralManagerStatePoweredOff:
            [self updateLog:@"CoreBluetooth BLE hardware is Powered off"];
            
            break;
        case CBCentralManagerStatePoweredOn:
            [self updateLog:@"CoreBluetooth BLE hardware is Powered on and ready"];
            //cbReady = true;
        case CBCentralManagerStateResetting:
            
            [self updateLog:@"CoreBluetooth BLE hardware is resetting"];
            break;
        case CBCentralManagerStateUnauthorized:
            
            [self updateLog:@"CoreBluetooth BLE state is unauthorized"];
            break;
        case CBCentralManagerStateUnknown:
            
            [self updateLog:@"CoreBluetooth BLE state is unknown"];
            break;
        case CBCentralManagerStateUnsupported:
            
            [self updateLog:@"CoreBluetooth BLE hardware is unsupported on this platform"];
            break;
        default:
            break;
    }
    
}

//已发现从机设备
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    [self updateLog:[NSString stringWithFormat:@"Did discover peripheral. peripheral: %@ rssi: %@, UUID: %@ advertisementData: %@ ", peripheral, RSSI, peripheral.UUID, advertisementData]];
    
    BOOL replace = NO;
    
    // Match if we have this device from before
    
    for (int ii=0; ii < nDevices.count; ii++) {
        CBPeripheral *p = [nDevices objectAtIndex:ii];
        if ([p isEqual:peripheral]) {
            [nDevices replaceObjectAtIndex:ii withObject:peripheral];
            replace = YES;
        }
    }
    if (!replace) {
        if ([peripheral.name isEqualToString:@"GhostyuSerialApp"]) {
            [nDevices addObject:peripheral];
            [self updateLog:@"has found GhostyuSerialApp！\r\n"];
            
            cbPeripheral = peripheral;
            [peripheralFound setTitle:[NSString stringWithFormat:@"%@",peripheral.name] forState:UIControlStateNormal];
            peripheralFound.hidden = false;
            
        }
        
    }
    
    
}


//已链接到从机
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral {
    
    [self updateLog:[NSString stringWithFormat:@"Connection successfull to peripheral: %@ with UUID: %@",peripheral,peripheral.UUID]];
    //Do somenthing after successfull connection.
    
    [peripheralFound setTitle:[NSString stringWithFormat:@"%@: Has Connected",peripheral.name] forState:UIControlStateNormal];
    
    //发现services
    //设置peripheral的delegate未self非常重要，否则，didDiscoverServices无法回调
    peripheral.delegate = self;
    [cbPeripheral discoverServices:nil];
    [self updateLog:@"finding services"];
}


//已断开从机的链接
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    [self updateLog:[NSString stringWithFormat:@"Disconnected from peripheral: %@ with UUID: %@",peripheral,peripheral.UUID]];
    //Do something when a peripheral is disconnected.
    
    [peripheralFound setTitle:[NSString stringWithFormat:@"%@: Has Disconnected",peripheral.name] forState:UIControlStateNormal];
    
}

- (void) centralManager:(CBCentralManager *)central didRetrieveConnectedPeripherals:(NSArray *)peripherals {
    
    [self updateLog:[NSString stringWithFormat:@"Currently connected peripherals :"]];
    int i = 0;
    for(CBPeripheral *peripheral in peripherals) {
        [self updateLog:[NSString stringWithFormat:@"[%d] - peripheral : %@ with UUID : %@",i,peripheral,peripheral.UUID]];
        //Do something on each connected peripheral.
    }
    
}

- (void) centralManager:(CBCentralManager *)central didRetrievePeripherals:(NSArray *)peripherals {
    
    [self updateLog:[NSString stringWithFormat:@"Currently known peripherals :"]];
    int i = 0;
    for(CBPeripheral *peripheral in peripherals) {
        
        [self updateLog:[NSString stringWithFormat:@"[%d] - peripheral : %@ with UUID : %@",i,peripheral,peripheral.UUID]];
        //Do something on each known peripheral.
    }
}





//delegate of CBPeripheral
//已搜索到services
-(void) peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    
    [self updateLog:@"Found Services."];
    
    int i=0;
    for (CBService *s in peripheral.services) {
        
        [self.nServices addObject:s];
        
    }
    
    
    for (CBService *s in peripheral.services) {
        [self updateLog:[NSString stringWithFormat:@"%d :Service UUID: %@(%@)",i,s.UUID.data,s.UUID]];
        i++;
        [peripheral discoverCharacteristics:nil forService:s];
    }
}

//已搜索到Characteristics
-(void) peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    [self updateLog:[NSString stringWithFormat:@"Found Characteristics in Service:%@ (%@)",service.UUID.data ,service.UUID]];
    
    for (CBCharacteristic *c in service.characteristics) {
        [self updateLog:[NSString stringWithFormat:@"Characteristic UUID: %@ (%@)",c.UUID.data,c.UUID]];
        [nCharacteristics addObject:c];
        
    }
}
//已读到char
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        return;
    }
    unsigned char data[characteristic.value.length];
    [characteristic.value getBytes:&data];
    
    
}

- (IBAction)scanButton:(id)sender {
    [self updateLog:@"Scan for Peripheral..."];
    [cbCM scanForPeripheralsWithServices:nil options:nil];
}

- (IBAction)connectPeripheral:(id)sender {
    if (cbReady ==false) {
        [self.cbCM connectPeripheral:cbPeripheral options:nil];
        textSend.hidden = false;
        buttonSend.hidden = false;
        cbReady = true;
    }else {
        [self.cbCM cancelPeripheralConnection:cbPeripheral];
        textSend.hidden = true;
        buttonSend.hidden = true;
        cbReady = false;
    }
    
}

- (IBAction)sendMsg:(id)sender {
    if (textSend.text.length > 0) {
        
        [self writeCharacteristic:cbPeripheral sUUID:@"FFF0" cUUID:@"FFF1" data:[textSend.text dataUsingEncoding:NSASCIIStringEncoding]];
        
        unsigned char dat='\n';
        [self writeCharacteristic:cbPeripheral sUUID:@"FFF0" cUUID:@"FFF1" data:[NSData dataWithBytes:&dat length:1]];
        [self updateLog:[NSString stringWithFormat:@"I Said:%@",textSend.text]];
        
    }
}
@end
