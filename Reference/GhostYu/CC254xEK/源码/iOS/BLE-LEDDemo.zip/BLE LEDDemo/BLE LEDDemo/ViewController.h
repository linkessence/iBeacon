//
//  ViewController.h
//  BLE LEDDemo
//
//  Created by liuyu on 13-6-3.
//  Copyright (c) 2013年 liuyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "BLEUtility.h"


@interface ViewController : UIViewController <CBCentralManagerDelegate,CBPeripheralDelegate>{
}

@property bool cbReady;
@property (nonatomic,strong) CBCentralManager *cbCM;
@property (strong,nonatomic) NSMutableArray *nDevices;
@property (strong,nonatomic) NSMutableArray *nServices;
@property (strong,nonatomic) NSMutableArray *nCharacteristics;

@property (strong,nonatomic) CBPeripheral *cbPeripheral;
@property (strong,nonatomic) CBService *cbServices;
@property (strong,nonatomic) CBCharacteristic *cbCharacteristcs;



@property (weak, nonatomic) IBOutlet UITextView *dbgText;
- (IBAction)scanButton:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *peripheralFound;
- (IBAction)connectPeripheral:(id)sender;
- (IBAction)led1Switch:(id)sender;
- (IBAction)led2Switch:(id)sender;
- (IBAction)led3Switch:(id)sender;

@end
