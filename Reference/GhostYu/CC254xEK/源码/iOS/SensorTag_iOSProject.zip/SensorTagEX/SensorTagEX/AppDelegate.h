//
//  AppDelegate.h
//  TI BLE SensorTag Example
//
//  Created by Ole Andreas Torvmark on 11/15/12.
//  Copyright (c) 2012 Texas Instruments. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
