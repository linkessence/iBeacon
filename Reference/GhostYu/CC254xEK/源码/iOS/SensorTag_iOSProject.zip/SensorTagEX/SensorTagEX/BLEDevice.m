//
//  BLEDevice.m
//
//  Created by Ole Andreas Torvmark on 9/17/12.
//  Copyright (c) 2012 Texas Instruments. All rights reserved.
//

#import "BLEDevice.h"

@implementation BLEDevice

@synthesize p,manager,setupData;

@end
