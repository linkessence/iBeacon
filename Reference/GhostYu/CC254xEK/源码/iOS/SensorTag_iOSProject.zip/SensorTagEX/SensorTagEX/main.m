//
//  main.m
//  TI BLE SensorTag Example
//
//  Created by Ole Andreas Torvmark on 11/15/12.
//  Copyright (c) 2012 Texas Instruments. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
