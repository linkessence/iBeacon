//
//  CarDefines.h
//  TI-BLE-Car1
//
//  Created by Albert Skog on 6/29/12.
//  Copyright (c) 2012 Texas Instruments. All rights reserved.
//

//Service and characteristics UUIDs
#define CAR_SERVICE_UUID        0xACC0
#define CAR_THROTTLE_UUID       0xACC1
#define CAR_STEERING_UUID       0xACC2

//Settings
#define DEFAULT_SCAN_DURATION           2
#define CAR_THROTTLE_CHANGE_THRESHOLD   3
#define CAR_STEERING_CHANGE_THRESHOLD   3