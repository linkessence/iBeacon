//
//  TIBLEViewController.h
//  TI-BLE-Car
//
//  Created by Albert Skog on 2012-08-03.
//  Copyright (c) 2012 Texas Instruments. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TIBLECar.h"

@interface TIBLEViewController : UIViewController <TIBLECarDelegate, UIAccelerometerDelegate> { 
    TIBLECar *t; //TI keyfob class (private)

}

// UI elements actions
- (IBAction)TIBLEUIScanForPeripheralsButton:(id)sender;
- (IBAction)accelerometerSwitchValueChanged:(UISwitch *)sender;

// Pan gesture callback
- (IBAction)controlKnob:(UIPanGestureRecognizer *)recognizer;

// Scan duration timer
- (void) connectionTimer:(NSTimer *)timer;

//Accelerometer handle
@property (nonatomic, retain) UIAccelerometer *accelerometer;

// UI elements outlets
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *TIBLEUISpinner;
@property (weak, nonatomic) IBOutlet UIImageView *TIBLEUIStatusIndicator;
@property (weak, nonatomic) IBOutlet UIImageView *throttleKnob;
@property (weak, nonatomic) IBOutlet UIImageView *steeringKnob;
@property (weak, nonatomic) IBOutlet UIButton *ScanForPeripheralsButton;

@property (weak, nonatomic) IBOutlet UISwitch *accelerometerSwitch;

@property (strong) UIImage *TIBLEUIStatusConnected;
@property (strong) UIImage *TIBLEUIStatusDisconnected;

@property CGPoint steeringCenter;
@property CGPoint throttleCenter;

@end
