//
//  TIBLEViewController.m
//  TI-BLE-Demo
//
//  Created by Albert Skog on 2012-08-03.
//  Copyright (c) 2012 Texas Instruments. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TIBLEViewController.h"
#import "TIBLECarDefines.h"

@implementation TIBLEViewController
@synthesize accelerometer;
@synthesize accelerometerSwitch;
@synthesize steeringKnob;
@synthesize ScanForPeripheralsButton;
@synthesize throttleKnob;
@synthesize steeringCenter;
@synthesize throttleCenter;
@synthesize TIBLEUISpinner;
@synthesize TIBLEUIStatusIndicator;
@synthesize TIBLEUIStatusConnected;
@synthesize TIBLEUIStatusDisconnected;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //Save the knob's positions
    steeringCenter = steeringKnob.center;
    throttleCenter = throttleKnob.center;
    
    //Set up the accelerometer
    self.accelerometer = [UIAccelerometer sharedAccelerometer];
    self.accelerometer.updateInterval = .1;
    self.accelerometer.delegate = nil;
    
    t = [[TIBLECar alloc] init];   // Init TIBLECar class.
    [t controlSetup:1];                 // Do initial setup of TIBLECar class.
    t.delegate = self;                  // Set TIBLECar delegate class to point at methods implemented in this class.
    
}

- (void)viewDidUnload
{
    [self setThrottleKnob:nil];
    [self setSteeringKnob:nil];
    [self setTIBLEUISpinner:nil];
    [self setTIBLEUIStatusIndicator:nil];
    [self setAccelerometerSwitch:nil];
    [self setScanForPeripheralsButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //Set up the connection status indicator
    self.TIBLEUIStatusConnected = [UIImage imageNamed:@"connected.png"];
    self.TIBLEUIStatusDisconnected = [UIImage imageNamed:@"disconnected.png"];
    [TIBLEUIStatusIndicator setImage:TIBLEUIStatusDisconnected];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    //Only allow while accelerometer control is disabled
    return !accelerometerSwitch.on;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation{
    
    //Move the status icons so they stay next to the connect/disconnect button
    CGPoint newCenter = CGPointMake(ScanForPeripheralsButton.center.x + 100, ScanForPeripheralsButton.center.y);
    [UIView animateWithDuration:0.05 animations:^{
        TIBLEUISpinner.center = newCenter;
        TIBLEUIStatusIndicator.center = newCenter;
    }];
    
    
}

//Connect or disconnect from the car. This will scan for peripherals and connect to the first peripheral presenting the RC Profile
- (IBAction)TIBLEUIScanForPeripheralsButton:(id)sender {
    if(t.activePeripheral.isConnected){
        
        [[t CM] cancelPeripheralConnection:[t activePeripheral]];
        [TIBLEUIStatusIndicator setImage:TIBLEUIStatusDisconnected];
    }
    else {
        
    if (t.peripherals) t.peripherals = nil;
    [t findBLEPeripherals:DEFAULT_SCAN_DURATION];   
    [NSTimer scheduledTimerWithTimeInterval:(float)2.0 target:self selector:@selector(connectionTimer:) userInfo:nil repeats:NO];
    [TIBLEUIStatusIndicator setHidden:YES];
    [TIBLEUISpinner startAnimating];
    }
}


//Called when car has been found and all services have been discovered
-(void) carReady {
    
    [TIBLEUISpinner stopAnimating];
    [TIBLEUIStatusIndicator setImage:TIBLEUIStatusConnected];
    [TIBLEUIStatusIndicator setHidden:NO];
}

//Method called when peripheral disconnects due to signal strength or power down
-(void) carDisconnected {
    [TIBLEUISpinner stopAnimating];
    [TIBLEUIStatusIndicator setImage:TIBLEUIStatusDisconnected];
    [TIBLEUIStatusIndicator setHidden:NO];
}

// Called when scan period is over to connect to the first found peripheral
- (void)connectionTimer:(NSTimer *)timer {
    if(t.peripherals.count > 0)
    {
        [t connectPeripheral:[t.peripherals objectAtIndex:0]];

    }
    else 
    {
        [TIBLEUISpinner stopAnimating];
        [TIBLEUIStatusIndicator setImage:TIBLEUIStatusDisconnected];
        [TIBLEUIStatusIndicator setHidden:NO];
    }
}

- (IBAction)accelerometerSwitchValueChanged:(UISwitch *)sender {    
    //Toggle accelerometer control by adding/removing the delegate
    if (sender.on == YES) {
        if (self.interfaceOrientation == UIInterfaceOrientationLandscapeLeft) {
            sender.on = NO;
        }
        else if (self.interfaceOrientation == UIInterfaceOrientationLandscapeRight) {
            sender.on = NO;
        }
        else {
            throttleCenter = throttleKnob.center;
            steeringCenter = steeringKnob.center;
            
            self.accelerometer.delegate = self;
        }
        
    }
    else if (sender.on == NO) {
        self.accelerometer.delegate = nil;
        
        throttleKnob.center = throttleCenter;
        steeringKnob.center = steeringCenter;
        
        int8_t value = 0;
        NSData *d = [[NSData alloc] initWithBytes:&value length:sizeof(int8_t)];
        [t writeValue:CAR_SERVICE_UUID characteristicUUID:CAR_STEERING_UUID p:[t activePeripheral] data:d];
        [t writeValue:CAR_SERVICE_UUID characteristicUUID:CAR_THROTTLE_UUID p:[t activePeripheral] data:d];
    }
    
}

- (void) accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration{
    if (accelerometerSwitch.on) {
        
        float steering = steeringCenter.x + 100*acceleration.x;
        if (steering > steeringCenter.x + 50) {
            steering = steeringCenter.x + 50;
        }
        else if (steering < steeringCenter.x - 50) {
            steering = steeringCenter.x - 50;
        }
        
        float throttle = throttleCenter.y - 100*acceleration.y;
        if (throttle > throttleCenter.y + 50) {
            throttle = throttleCenter.y + 50;
        }
        else if (throttle < throttleCenter.y - 50) {
            throttle = throttleCenter.y - 50;
        }
        
        steeringKnob.center = CGPointMake(steering, steeringCenter.y);
        throttleKnob.center = CGPointMake(throttleCenter.x, throttle);
        
        //UI is done, now update the values on the car     
        if(t.activePeripheral.isConnected && t.steeringChar && t.throttleChar)
        {
            int8_t steeringValue;
            int8_t throttleValue;
            NSData *d;
            
            throttleValue = -((int8_t)throttle - throttleCenter.y);
            d = [[NSData alloc] initWithBytes:&throttleValue length:sizeof(int8_t)];
            [t writeValue:CAR_SERVICE_UUID characteristicUUID:CAR_THROTTLE_UUID p:[t activePeripheral] data:d];
            
            // Square the knob value for better feel and fit it back in the +/- 50 range
            // Increase magic number 7 to make the car turn less
            float f = (steering - steeringCenter.x)/7.0;
            f *= ( f > 0 )? f : -f;
            steeringValue = (int8_t)f;
            
            d = [[NSData alloc] initWithBytes:&steeringValue length:sizeof(int8_t)];
            [t writeValue:CAR_SERVICE_UUID characteristicUUID:CAR_STEERING_UUID p:[t activePeripheral] data:d];
            
        }
    }
}


//Moves the knobs and send updated values to the car
- (IBAction)controlKnob:(UIPanGestureRecognizer *)recognizer{
    if (!accelerometerSwitch.on) {
        
        //UI stuff
        CGPoint translation = [recognizer translationInView:self.view];
        CGPoint newPoint;
        CGPoint *center;
        
        //Car stuff
        static int8_t throttle = 0;
        static int8_t steering = 0;
        int8_t *value;
        int8_t new_value;
        int8_t threshold;
        int charUUID;
        
        //First move the knob in the GUI    
        if (recognizer.view == steeringKnob) {
            center = &steeringCenter;
        }
        else if (recognizer.view == throttleKnob){
            center = &throttleCenter;
        }
        
        switch (recognizer.state) {
            case UIGestureRecognizerStateBegan:
            {
                *center = recognizer.view.center;
            }
                break;
                
            case UIGestureRecognizerStateChanged:
            {
                if (recognizer.view == steeringKnob) {
                    newPoint = CGPointMake(recognizer.view.center.x + translation.x,
                                           center->y);
                    
                    //The knobs can move +/- 50 points...
                    //TODO: moving the knob fast over the edge can cause it to drift off from the finger
                    if (newPoint.x > center->x + 50) {
                        recognizer.view.center = CGPointMake(center->x + 50.0, center->y);
                    }
                    else if (newPoint.x < center->x - 50) {
                        recognizer.view.center = CGPointMake(center->x - 50.0, center->y);
                    }
                    else {
                        recognizer.view.center = newPoint;
                        [recognizer setTranslation:CGPointZero inView:self.view];
                    }
                }
                else if (recognizer.view == throttleKnob) {
                    newPoint = CGPointMake(center->x,
                                           recognizer.view.center.y + translation.y);
                    
                    if (newPoint.y > center->y + 50) {
                        recognizer.view.center = CGPointMake(center->x, center->y + 50);
                    }
                    else if (newPoint.y < center->y - 50) {
                        recognizer.view.center = CGPointMake(center->x, center->y - 50);
                    }
                    else {
                        recognizer.view.center = newPoint;
                        [recognizer setTranslation:CGPointZero inView:self.view];
                    }
                }
            }
                break;
                
            case UIGestureRecognizerStateEnded:
            {
                [UIView animateWithDuration:0.1 animations:^{recognizer.view.center =*center;}];
            }
                break;
                
            default:
                //Do nothing
                break;
        }
        
        //UI is done, now update the values on the car     
        if(t.activePeripheral.isConnected && t.steeringChar && t.throttleChar)
        {
            
            if (recognizer.view == throttleKnob) {
                value = &throttle;
                new_value = -((int8_t)recognizer.view.center.y - throttleCenter.y);
                threshold = CAR_THROTTLE_CHANGE_THRESHOLD;
                charUUID = CAR_THROTTLE_UUID;
            }
            else if(recognizer.view == steeringKnob){
                value = &steering;
                
                // Square the knob value for better feel and fit it back in the +/- 50 range
                // Increase magic number 7 to make the car turn less
                float f = (recognizer.view.center.x - steeringCenter.x)/7.0;
                f *= ( f > 0 )? f : -f;
                new_value = (int8_t)f;
                
                threshold = CAR_STEERING_CHANGE_THRESHOLD;
                charUUID = CAR_STEERING_UUID;
            }
            
            // Do a threshold filtering so we dont send too many commands
            if (new_value > *value + threshold || new_value < *value - threshold)
            {
                *value = new_value;
                NSData *d = [[NSData alloc] initWithBytes:value length:sizeof(int8_t)];
                [t writeValue:CAR_SERVICE_UUID characteristicUUID:charUUID p:[t activePeripheral] data:d];
                
            }
        }
    }
}



@end
